require('dotenv').config();

const { startServer } = require('./src/server');

startServer();
